The minplayer is a MIT, minimalistic, skinable, plugin based Flash media player.

In addition to being a minimal Flash player, it was built with a solid API so that any
JavaScript widget can communicate to this player easily and effectively controlling it
from outside sources.

This player was written with several objectives.

 - Small and lightweight
 - Solid plugin based system to easily build on top of this player without recompiling.
 - Complete JavaScript API.
 - Configurable using external XML files.