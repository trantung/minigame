<?php

namespace Drupal\testmod_psr0_lib;

class Foo {}
