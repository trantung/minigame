<?php

namespace Drupal\testmod_psr4_src;

class Foo {}
