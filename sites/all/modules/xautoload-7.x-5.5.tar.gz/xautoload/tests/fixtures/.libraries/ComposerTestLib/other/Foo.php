<?php


namespace ComposerTestLib\Other;


class Foo {

} 
