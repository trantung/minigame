Facebook Comments Box for Drupal 7
**********************************

Adds Facebook Comments Box to any content type on your site.

This module adds a block to your site that you can add to any region to
display Facebook Comments. You can control which node types it gets
attached to, setup the parameters of the comments, who the administrator
is, etc.

Configure your Facebook Comments at /admin/config/facebook_comments_box

Add the block Facebook Comments as you would any other block to a
region.



***************************************************************************
Created with <3 by humans at TEN7.com
